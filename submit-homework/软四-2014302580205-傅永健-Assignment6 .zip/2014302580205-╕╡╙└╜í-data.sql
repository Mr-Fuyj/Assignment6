

INSERT INTO `2014302580205_pet` VALUES (1,'dog','bone','water','ground','play',200),
										(2,'cat','fish','milk','roof','hug',80),
                                        (3,'turtle','fish,shrimp','sea water','sea water','bask',90),
                                        (4,'parrot','nuts,seeds','water','tree','fly',20),
                                        (5,'hamster','Sunflower seed','water','corner','eat',90),
                                        (6,'squirrel','pine cone','water','tree hole,underground','play',80),
                                        (7,'rabbit','carrot','water','grassland,underground','eat',30),
                                        (8,'snake','mouse','water','hole','bask',90),
                                        (9,'lizard','bug','water','tree','bask',70),
                                        (10,'fish','aquatic plant','water','water','swim',60),
                                        (11,'myna','earthworm','water','tree','fly',150),
                                        (12,'canary','millet','water','tree','sing',50);
insert into 2014302580205_user value(null,'test','test','123',100000,'1,0 2,0 3,0 4,1 5,0 6,2 7,0 8,0 9,0 10,0 11,0 12,0');