package iss.java.mail;
import javax.mail.Authenticator;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;

/**
 * ����������֤����
 * 
 *
 */
public class MailAuthenticator2014302580205 extends Authenticator{
	private String m_userName;
	private String m_password;
    /**
     * ���캯��
     * @param userName �û���
     * @param password ����
     * @throws 
     */
	public MailAuthenticator2014302580205(String userName,String password) {
		m_userName=userName;
		m_password=password;
	}
	

	@Override
	protected PasswordAuthentication getPasswordAuthentication(){
		return new PasswordAuthentication(m_userName, m_password);
	}

}
