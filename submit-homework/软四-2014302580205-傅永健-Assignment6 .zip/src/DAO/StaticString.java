package DAO;

public class StaticString {
	static public String URL=new String("jdbc:mysql://127.0.0.1:3306/my_schema");
	static public String USER_NAME=new String("root");
	static public String PASSWORD=new String("123456");
	//static public String URL=new String("jdbc:mysql://localhost:3306/petstore");
	//static public String USER_NAME=new String("root");
	//static public String PASSWORD=new String("yongjian");
	static public String INSTRUCTION_FOR_PET=new String("select * from 2014302580205_pet");
	static public String INSTRUCTION_FOR_USER=new String("select * from 2014302580205_user");
	static public String NUUL_CART=new String("1,0 2,0 3,0 4,0 5,0 6,0 7,0 8,0 9,0 10,0 11,0 12,0");
}
