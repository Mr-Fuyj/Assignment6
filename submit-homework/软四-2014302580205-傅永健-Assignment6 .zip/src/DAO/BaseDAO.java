package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;

import pojo.Entity;

public abstract class BaseDAO {
	protected Connection m_connetction;
	
	
	public void ConnectToSQL() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		m_connetction=DriverManager.getConnection(StaticString.URL, StaticString.USER_NAME, StaticString.PASSWORD);
	}
	
	abstract public Entity getData();
	abstract public void outToSQL();
	abstract public void setList(Entity e);
}
