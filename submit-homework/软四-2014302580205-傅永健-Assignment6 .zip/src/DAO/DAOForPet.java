package DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import pojo.Entity;
import pojo.Pet;
import pojo.PetList;

public class DAOForPet extends BaseDAO {
	private PetList m_pet;
	
	public  DAOForPet() throws ClassNotFoundException{
		m_pet=new PetList();
		
	}

	@Override
	public Entity getData() {
		try {
			super.ConnectToSQL();
			Statement statement=super.m_connetction.createStatement();
			ResultSet result=statement.executeQuery(StaticString.INSTRUCTION_FOR_PET);
			
			while(result.next()){
				m_pet.addPet(new Pet(result.getInt(1), result.getString(2), result.getString(3),
						result.getString(4), result.getString(5), result.getString(6),result.getInt(7)));
			}
			statement.close();
			m_connetction.close();
		} catch (SQLException | ClassNotFoundException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		
		return m_pet;
	}

	@Override
	public void outToSQL() {
		try {
			super.ConnectToSQL();
			Statement statement=super.m_connetction.createStatement();
			statement.executeUpdate("truncate table 2014302580205_pet");
			statement.close();
			PreparedStatement ps=super.m_connetction.prepareStatement("insert into 2014302580205_pet value(?,?,?,?,?,?,?);");
			for(Pet p:m_pet.getPetList()){
				ps.setObject(1, null);
				ps.setObject(2, p.getName());
				ps.setObject(3, p.getEat());
				ps.setObject(4, p.getDrink());
				ps.setObject(5, p.getLive());
				ps.setObject(6, p.getHobby());
				ps.setObject(7, p.getPrice());
				ps.executeUpdate();
			}
			ps.close();
			super.m_connetction.close();
		} catch (ClassNotFoundException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		
	}

	@Override
	public void setList(Entity e) {
		m_pet=(PetList)e;
		
	}
	
}
