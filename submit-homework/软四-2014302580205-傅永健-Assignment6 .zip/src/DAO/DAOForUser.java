package DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import pojo.Entity;
import pojo.Pet;
import pojo.User;
import pojo.UserList;

public class DAOForUser extends BaseDAO {
	private UserList m_userList;
	
	public DAOForUser(){
		m_userList=new UserList();
	}
	
	public void setUserList(UserList ul){
		m_userList=ul;
	}
	
	@Override
	public Entity getData() {
		try {
			super.ConnectToSQL();
			Statement statement=super.m_connetction.createStatement();
			ResultSet result=statement.executeQuery(StaticString.INSTRUCTION_FOR_USER);
			
			while(result.next()){
				m_userList.addUser(new User(result.getInt(1), result.getString(2),
						result.getString(3),result.getString(4), result.getInt(5),result.getString(6)));
			}
			statement.close();
			m_connetction.close();
		} catch (SQLException | ClassNotFoundException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		return m_userList;
	}

	@Override
	public void outToSQL() {
		try {
			super.ConnectToSQL();
			Statement statement=super.m_connetction.createStatement();
			statement.executeUpdate("truncate table 2014302580205_user");
			statement.close();
			PreparedStatement ps=super.m_connetction.prepareStatement("insert into 2014302580205_user value(?,?,?,?,?,?);");
			for(User u:m_userList.getUserList()){
				ps.setObject(1, null);
				ps.setObject(2, u.getUserName());
				ps.setObject(3, u.getPassword());
				ps.setObject(4, u.getEmail());
				ps.setObject(5, u.getBalance());
				ps.setObject(6, u.getCart());
				ps.executeUpdate();
			}
			ps.close();
			super.m_connetction.close();
		} catch (ClassNotFoundException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		
		
	}

	@Override
	public void setList(Entity e) {
		m_userList=(UserList)e;
	}

}
