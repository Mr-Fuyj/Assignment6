package GUI;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JCheckBox;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.awt.Font;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

import pojo.Goods;
import pojo.Pet;
import pojo.PetList;
import pojo.User;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


public class PetPanel extends JPanel {
	private JTable m_PetTable;
	private JTextField m_wantID;
	private PetList m_petList;
	private User m_user;
	private MainWindows m_mainWindows;

	/**
	 * Create the panel.
	 */
	public PetPanel(PetList pl,User u,MainWindows mw) {
		
		m_petList=pl;
		m_user=u;
		m_mainWindows=mw;
		
		setLayout(null);
		
		m_PetTable = new JTable();
		m_PetTable.setColumnSelectionAllowed(true);
		m_PetTable.setCellSelectionEnabled(true);
		m_PetTable.setFillsViewportHeight(true);
		m_PetTable.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		m_PetTable.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"ID", "Name", "Eat", "Drink", "Live", "Hobby", "Price"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class, String.class, String.class, String.class, String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		m_PetTable.getColumnModel().getColumn(0).setPreferredWidth(29);
		m_PetTable.getColumnModel().getColumn(1).setPreferredWidth(52);
		m_PetTable.getColumnModel().getColumn(2).setPreferredWidth(123);
		m_PetTable.getColumnModel().getColumn(3).setPreferredWidth(60);
		m_PetTable.getColumnModel().getColumn(4).setPreferredWidth(156);
		m_PetTable.getColumnModel().getColumn(5).setPreferredWidth(49);
		m_PetTable.getColumnModel().getColumn(6).setPreferredWidth(34);
		m_PetTable.setBounds(14, 175, 629, 192);
		
		DefaultTableModel tm=(DefaultTableModel)m_PetTable.getModel();
		ArrayList<Pet>pList=m_petList.getPetList();
		for(Pet p:pList){
			String[]attr=new String [7];
			attr[0]=String.valueOf(p.getID());
			attr[1]=p.getName();
			attr[2]=p.getEat();
			attr[3]=p.getDrink();
			attr[4]=p.getLive();
			attr[5]=p.getHobby();
			attr[6]=String.valueOf(p.getPrice());
			tm.addRow(attr);
		}
		
		add(m_PetTable);
		
		JLabel lblNewLabel = new JLabel("ID");
		lblNewLabel.setBounds(32, 156, 30, 18);
		add(lblNewLabel);
		
		JLabel lblName = new JLabel("Name");
		lblName.setBounds(83, 156, 72, 18);
		add(lblName);
		
		JLabel lblEat = new JLabel("Eat");
		lblEat.setBounds(176, 156, 72, 18);
		add(lblEat);
		
		JLabel lblDrink = new JLabel("Drink");
		lblDrink.setBounds(284, 156, 72, 18);
		add(lblDrink);
		
		JLabel lblLive = new JLabel("Live");
		lblLive.setBounds(417, 156, 72, 18);
		add(lblLive);
		
		JLabel lblHobby = new JLabel("Hobby");
		lblHobby.setBounds(524, 156, 72, 18);
		add(lblHobby);
		
		JLabel lblOurPet = new JLabel("Our Pet");
		lblOurPet.setFont(new Font("΢���ź�", Font.PLAIN, 48));
		lblOurPet.setBounds(253, 35, 187, 55);
		add(lblOurPet);
		
		m_wantID = new JTextField();
		m_wantID.setBounds(403, 427, 86, 24);
		add(m_wantID);
		m_wantID.setColumns(10);
		
		JLabel lblYouWantAinput = new JLabel("You want a......(input an ID)");
		lblYouWantAinput.setFont(new Font("΢���ź�", Font.PLAIN, 24));
		lblYouWantAinput.setBounds(83, 418, 306, 33);
		add(lblYouWantAinput);
		
		JButton m_btnAddToCart = new JButton("Add To Cart");
		m_btnAddToCart.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Map goodMap=m_user.getGoods().getMap();
				int num=Integer.valueOf(m_wantID.getText());
				if(num<1||num>12){
					JOptionPane.showMessageDialog(null, "We do not have that pet!!!", "Wrong!",JOptionPane.ERROR_MESSAGE);
					m_wantID.setText("");
					return;
				}
				int acount=(int)goodMap.get(num);
				goodMap.put(num,acount+1);
				m_user.getGoods().setMap(goodMap);
				m_wantID.setText("");
				m_mainWindows.save();
			}
		});
		m_btnAddToCart.setBounds(513, 426, 130, 27);
		add(m_btnAddToCart);
		
		JButton m_btnGoToCart = new JButton("Go To Cart");
		m_btnGoToCart.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				m_mainWindows.changeToCart();
			}
		});
		m_btnGoToCart.setBounds(513, 466, 130, 27);
		add(m_btnGoToCart);
		
		JLabel lblPrice = new JLabel("Price");
		lblPrice.setBounds(594, 156, 72, 18);
		add(lblPrice);

	}
}
