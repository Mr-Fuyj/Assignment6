package GUI;
import java.awt.EventQueue;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import DAO.BaseDAO;
import DAO.DAOForPet;
import DAO.DAOForUser;
import pojo.Goods;
import pojo.PetList;
import pojo.UserList;


public class Main {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainWindows window = new MainWindows();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		//BaseDAO bd=new DAOForUser();
		//UserList ul=(UserList)bd.getData();
		//bd.outToSQL();
		//ul.outToConsole();
	
		//Map<Integer, Integer>a = null;
		//a=new HashMap<Integer,Integer>();
		//for(int i=0;i<12;i++){
		//	a.put(i+1, i%4);
		//}
		//Goods g=new Goods(a);
		//g.outToConsole();
		//Goods g2=new Goods("1,0 2,1 3,2 4,3 5,0 6,1 7,2 8,3 9,0 10,1 11,2 12,3");
		//g2.outToConsole();
	}
}
