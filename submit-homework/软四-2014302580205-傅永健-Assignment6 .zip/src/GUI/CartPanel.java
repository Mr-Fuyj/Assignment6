package GUI;
import javax.swing.JPanel;

import java.awt.CardLayout;

import javax.swing.JButton;

import java.awt.Font;
import java.util.ArrayList;
import java.util.Map;
import java.util.Vector;

import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import javax.swing.JOptionPane;

import DAO.StaticString;
import pojo.Goods;
import pojo.Pet;
import pojo.PetList;
import pojo.User;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


public class CartPanel extends JPanel {

	private MainWindows m_mainWindows;
	private User m_user;
	private PetList m_petList;
	private JList m_goodsList;
	private int m_sumPrice;
	
	
	
	public CartPanel(MainWindows mw,User u) {
		
		m_mainWindows=mw;
		m_user=u;
		m_petList=m_mainWindows.getPetList();
		
		setLayout(null);
		
		JButton m_payButton = new JButton("Pay");
		m_payButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(m_user.getBalance()-m_sumPrice>0){
					m_user.setBalance(m_user.getBalance()-m_sumPrice);
					m_user.setGoods(StaticString.NUUL_CART);
					m_mainWindows.save();
					freshPanel();
					m_mainWindows.changeToCart();
				}else{
					//JOptionPane.showMessageDialog(null, "You Don't Have So Many Money!\nBut We Have Given Your More 10000 Dollar.", 
						//	"Wrong!", JOptionPane.ERROR_MESSAGE);
					int inputValue = Integer.valueOf(JOptionPane.showInputDialog("You do not have enough money.Please recharge:"));
					m_user.setBalance(m_user.getBalance()+inputValue);
					m_mainWindows.save();
					m_mainWindows.changeToCart();
				}
			}
		});
		m_payButton.setToolTipText("");
		m_payButton.setFont(new Font("΢���ź�", Font.PLAIN, 26));
		m_payButton.setBounds(495, 484, 137, 43);
		add(m_payButton);
		
		JLabel lblGoodsList = new JLabel("Goods List:");
		lblGoodsList.setFont(new Font("΢���ź�", Font.PLAIN, 36));
		lblGoodsList.setBounds(89, 77, 235, 58);
		add(lblGoodsList);
		
		m_goodsList = new JList();
		m_goodsList.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		m_goodsList.setModel(new AbstractListModel() {
			String[] values = new String[] {};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		m_goodsList.setBounds(89, 138, 298, 350);
		add(m_goodsList);
		freshPanel();
		
		
		
		
		
		
		JButton m_backButton = new JButton("Back");
		m_backButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				m_mainWindows.changeToPet();
			}
		});
		m_backButton.setFont(new Font("΢���ź�", Font.PLAIN, 18));
		m_backButton.setBounds(14, 13, 76, 27);
		add(m_backButton);

	}
	
	public void freshPanel(){
		ArrayList<Pet>petList=m_petList.getPetList();
		Vector<String>goodsVector=new Vector<String>();
		Map goodMap=m_user.getGoods().getMap();
		m_sumPrice=0;
		for(int i=1;i<=goodMap.size();i++){
			if((int)goodMap.get(i)!=0){
				int num=(int)goodMap.get(i);
				String name=petList.get(i-1).getName();
				int price=num*(petList.get(i-1).getPrice());
				m_sumPrice+=price;
				String message=String.format("%s for %d :%d dollar", name,num,price);
				goodsVector.add(message);
			}
		}
		goodsVector.add(String.format("All account to %d dollar.",m_sumPrice));
		goodsVector.add(String.format("Your banlance : %d dollar.",m_user.getBalance()));
		//((DefaultListModel)(m_goodsList.getModel())).removeAllElements();
		m_goodsList.setListData(goodsVector);
	}
}
