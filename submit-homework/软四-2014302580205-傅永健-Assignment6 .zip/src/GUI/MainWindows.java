package GUI;
import java.awt.EventQueue;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JPanel;

import pojo.PetList;
import pojo.User;
import pojo.UserList;
import DAO.BaseDAO;
import DAO.DAOForPet;
import DAO.DAOForUser;


public class MainWindows {

	private JFrame frame;
	private JPanel m_cartPanel;
	private JPanel m_petPanel;
	private JPanel m_authenticationPanel;

	
	private PetList m_petList;
	private UserList m_userList;
	
	//For test
	private int m_check=1234;
	
	
	public MainWindows() throws ClassNotFoundException {
		initialize();
		frame.setVisible(true);
	}

	public void setPetPanel(PetPanel petPanel){
		m_petPanel=petPanel;
		frame.add(m_petPanel);
	}
	
	public void setCartPanel(CartPanel cartPanel){
		m_cartPanel=cartPanel;
		frame.add(m_cartPanel);
	}

	public PetList getPetList() {
		return m_petList;
	}
	
	private void initialize() throws ClassNotFoundException {
		BaseDAO petDAO=new DAOForPet();
		m_petList=(PetList)petDAO.getData();
		BaseDAO userDAO=new DAOForUser();
		m_userList=(UserList)userDAO.getData();
		
		frame = new JFrame();
		frame.setBounds(100, 100, 680, 540);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		m_authenticationPanel=new AuthenticationPanel(m_userList,this);
		
		
		
		m_authenticationPanel.setBounds(0, 0, 680, 540);
		frame.getContentPane().add(m_authenticationPanel);
		//frame.setVisible(true);
		
		
		
	}
	
	public void changeToPet() {
		m_authenticationPanel.setVisible(false);
		m_cartPanel.setVisible(false);
		m_petPanel.setBounds(0, 0, 680, 540);
		m_petPanel.setVisible(true);
		frame.repaint();
	}
	
	public void changeToCart(){
		m_petPanel.setVisible(false);
		m_cartPanel.setVisible(true);
		m_cartPanel.setBounds(0, 0, 680, 540);
		((CartPanel)m_cartPanel).freshPanel();
		frame.repaint();
	}
	
	public void save(){
		DAOForUser dao=new DAOForUser();
		try {
			dao.ConnectToSQL();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		dao.setUserList(m_userList);
		dao.outToSQL();
	}
}
