package GUI;
import iss.java.mail.IMailService;

import javax.mail.MessagingException;
import javax.swing.JPanel;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

import org.reflections.Reflections;

import DAO.StaticString;
import pojo.Cart;
import pojo.Entity;
import pojo.Goods;
import pojo.User;
import pojo.UserList;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Random;
import java.util.Set;


public class AuthenticationPanel extends JPanel {
	private JTextField m_loginUserName;
	private JPasswordField m_loginPassword;
	private JTextField m_registUserName;
	private JTextField m_registPassword;
	private UserList m_userList;
	private MainWindows m_mw;
	private JTextField m_email;
	private JTextField m_inputAuth;
	private int m_authCode=0;

	/**
	 * Create the panel.
	 */
	public AuthenticationPanel(UserList us,MainWindows mw) {
		
		m_mw=mw;
		m_userList=us;
		
		setLayout(null);
		
		JLabel lblLogInOr = new JLabel("Log In OR Sign In");
		lblLogInOr.setFont(new Font("΢���ź�", Font.PLAIN, 42));
		lblLogInOr.setBounds(150, 13, 395, 57);
		add(lblLogInOr);
		
		JPanel m_loginPanel = new JPanel();
		m_loginPanel.setToolTipText("\u7528\u6237\u540D");
		m_loginPanel.setBounds(126, 109, 395, 180);
		add(m_loginPanel);
		m_loginPanel.setLayout(null);
		
		m_loginUserName = new JTextField();
		m_loginUserName.setFont(new Font("����", Font.PLAIN, 17));
		m_loginUserName.setToolTipText("");
		m_loginUserName.setBounds(93, 13, 247, 35);
		m_loginPanel.add(m_loginUserName);
		m_loginUserName.setColumns(10);
		
		JLabel lblUsername = new JLabel("userName:");
		lblUsername.setFont(new Font("����", Font.PLAIN, 17));
		lblUsername.setBounds(14, 16, 88, 27);
		m_loginPanel.add(lblUsername);
		
		JLabel lblPassword = new JLabel("password:");
		lblPassword.setFont(new Font("����", Font.PLAIN, 17));
		lblPassword.setBounds(14, 78, 88, 18);
		m_loginPanel.add(lblPassword);
		
		m_loginPassword = new JPasswordField();
		m_loginPassword.setFont(new Font("����", Font.PLAIN, 17));
		m_loginPassword.setBounds(93, 76, 247, 35);
		m_loginPanel.add(m_loginPassword);
		
		JButton m_loginButton = new JButton("LogIn");
		m_loginButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				String tName=m_loginUserName.getText();
				String tPassword=String.valueOf(m_loginPassword.getPassword());
				ArrayList<User> userList=m_userList.getUserList();
				for(User u:userList){
					if(u.getUserName().equals(tName)&&u.getPassword().equals(tPassword)){
						m_mw.setPetPanel(new PetPanel(m_mw.getPetList(), u, m_mw));
						m_mw.setCartPanel(new CartPanel(m_mw, u));
						m_mw.changeToPet();
						m_loginPassword.setText("");
						m_loginUserName.setText("");
						return;
					}
				}
				JOptionPane.showMessageDialog(null, "Do not have that user Or wrong password!", "wrong", JOptionPane.ERROR_MESSAGE);
				m_loginPassword.setText("");
				m_loginUserName.setText("");
			}
		});
		m_loginButton.setBounds(148, 140, 113, 27);
		m_loginPanel.add(m_loginButton);
		
		JPanel m_registPanel = new JPanel();
		m_registPanel.setBounds(126, 302, 395, 225);
		add(m_registPanel);
		m_registPanel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("password:");
		lblNewLabel.setBounds(14, 44, 82, 18);
		m_registPanel.add(lblNewLabel);
		
		JLabel lblUsername_1 = new JLabel("userName:");
		lblUsername_1.setBounds(14, 13, 92, 18);
		m_registPanel.add(lblUsername_1);
		
		m_registUserName = new JTextField();
		m_registUserName.setBounds(84, 7, 246, 24);
		m_registPanel.add(m_registUserName);
		m_registUserName.setColumns(10);
		
		m_registPassword = new JTextField();
		m_registPassword.setBounds(84, 44, 247, 24);
		m_registPanel.add(m_registPassword);
		m_registPassword.setColumns(10);
		
		JButton m_registButton = new JButton("signIn");
		m_registButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String tName=m_registUserName.getText();
				String tPassword=m_registPassword.getText();
				ArrayList<User> userList=m_userList.getUserList();
				for(User u:userList){
					if(u.getUserName().equals(tName)&&u.getPassword().equals(tPassword)){
						JOptionPane.showMessageDialog(null, "Already have that user!", "Wrong!", JOptionPane.ERROR_MESSAGE);
						m_registPassword.setText("");
						m_registUserName.setText("");
						return;
					}
				}
				if(m_authCode==0){
					JOptionPane.showMessageDialog(null, "Please get your Auth Code!!! ", "Wrong!", JOptionPane.ERROR_MESSAGE);
					return;
				}
				if(Integer.valueOf(m_inputAuth.getText())!=999&&Integer.valueOf(m_inputAuth.getText())!=m_authCode){
					JOptionPane.showMessageDialog(null, "Wrong code!!!", "Wrong!", JOptionPane.ERROR_MESSAGE);
					return;
				}
				JOptionPane.showMessageDialog(null, "Congratulation! We have given you 100 dollar! ", "Congratuation!", JOptionPane.DEFAULT_OPTION);
				User u=new User(userList.size(), tName, tPassword, m_email.getText(), 100, StaticString.NUUL_CART);
				m_userList.addUser(u);
				u=userList.get(userList.size()-1);
				m_mw.setPetPanel(new PetPanel(m_mw.getPetList(), u, m_mw));
				m_mw.setCartPanel(new CartPanel(m_mw, u));
				m_mw.save();
				m_mw.changeToPet();
			}
		});
		m_registButton.setBounds(127, 178, 121, 27);
		m_registPanel.add(m_registButton);
		
		m_email = new JTextField();
		m_email.setBounds(84, 75, 246, 24);
		m_registPanel.add(m_email);
		m_email.setColumns(10);
		
		JButton btnGet = new JButton("getAuthCode");
		btnGet.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				
				
				
				Reflections reflections = new Reflections("iss.java.mail");
		        Set<Class<? extends IMailService>> impls = reflections.getSubTypesOf(IMailService.class);
		        Class<? extends IMailService> homework = impls.iterator().next();
		    	//MyMail2014302580205 homework=new MyMail2014302580205();
				try {
					IMailService service = homework.newInstance();
					service.connect();
					String name = homework.getName();
			        String id = String.valueOf(name.length()-13);
			        System.out.println(id);
			        Random r=new Random();
			        int random = r.nextInt(10000);
			        while(random<1000){
			        	random=r.nextInt(10000);
			        }
			        m_authCode=random;
			        service.send(m_email.getText(), "��֤",String.format("������֤��Ϊ��%d", m_authCode));
			        JOptionPane.showMessageDialog(null, "Auth code has been already sent to your email.Check it or use the code 999.", " ", JOptionPane.DEFAULT_OPTION);
			        
			        
			        
				} catch (InstantiationException | IllegalAccessException | MessagingException e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
			}
		});
		btnGet.setBounds(127, 112, 121, 27);
		m_registPanel.add(btnGet);
		
		JLabel lblEmail = new JLabel("e-Mail:");
		lblEmail.setBounds(14, 75, 72, 18);
		m_registPanel.add(lblEmail);
		
		JLabel lblInputauthcode = new JLabel("inputAuthCode:");
		lblInputauthcode.setBounds(14, 147, 121, 18);
		m_registPanel.add(lblInputauthcode);
		
		m_inputAuth = new JTextField();
		m_inputAuth.setBounds(127, 144, 121, 24);
		m_registPanel.add(m_inputAuth);
		m_inputAuth.setColumns(10);

	}
}
