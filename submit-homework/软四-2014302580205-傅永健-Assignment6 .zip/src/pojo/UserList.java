package pojo;

import java.util.ArrayList;

public class UserList extends Entity {
	private ArrayList<User> m_user;
	
	public UserList() {
		m_user=new ArrayList<User>();
	}
	
	public void addUser(User user){
		m_user.add(new User(user.getID(), user.getUserName(),
				user.getPassword(), user.getEmail(), user.getBalance(),user.getCart()));
	}
	
	public ArrayList<User> getUserList(){
		return m_user;
	}
	
	
	//For test
	public void outToConsole(){
		for(User u:m_user){
			System.out.printf("%d %s %s %s %d %s", 
					u.getID(),u.getUserName(),u.getPassword(),u.getEmail(),u.getBalance(),u.getCart());
		}
	}
}
