package pojo;

import java.util.HashMap;
import java.util.Map;

public class Goods {
	private Map<Integer,Integer> m_cartMap;
	private String m_cartString;
	
	public Goods(Map<Integer, Integer>cart){
		m_cartMap=cart;
		String [] temp=new String [12];
		for(int i=0;i<temp.length;i++){
			temp[i]=new String(String.valueOf(i+1)+","+String.valueOf(cart.get(i+1)));
		}
		for(int i=1;i<temp.length;i++){
			temp[0]+=new String(" "+temp[i]);
		}
		m_cartString=temp[0];
	}
	
	public Goods(String cart){
		m_cartMap=new HashMap<Integer, Integer>();
		m_cartString=cart;
		String []temp=cart.split(" ");
		String []couple;
		for(int i=0;i<temp.length;i++){
			couple=temp[i].split(",");
			m_cartMap.put(Integer.parseInt(couple[0]),Integer.parseInt(couple[1]));
		}
		outToConsole();
	}
	
	public Map<Integer, Integer> getMap() {
		return m_cartMap;
	}
	
	public void setMap(Map<Integer, Integer> map){
		m_cartMap=map;
		String [] temp=new String [12];
		for(int i=0;i<temp.length;i++){
			temp[i]=new String(String.valueOf(i+1)+","+String.valueOf(m_cartMap.get(i+1)));
		}
		for(int i=1;i<temp.length;i++){
			temp[0]+=new String(" "+temp[i]);
		}
		m_cartString=temp[0];
	}
	
	//For test
	public void outToConsole(){
		for(int i=0;i<m_cartMap.size();i++){
			//System.out.println((i+1)+"       "+m_cartMap.get(i+1));
		}
		System.out.println(m_cartString);
	}

	public void setGood(int kind, int addAmount) {
		m_cartMap.put(kind, addAmount);
	}
	
	public String getCart(){
		return m_cartString;
	}
}
