package pojo;

public class Entity {

}
