package pojo;

public class Pet {
	private int m_ID;
	private String m_name;
	private String m_eat;
	private String m_drink;
	private String m_live;
	private String m_hobby;
	private int m_price;
	
	public Pet(int ID,String name,String eat,String drink,String live,String hobby,int price){
		m_ID=ID;
		m_name=name;
		m_eat=eat;
		m_drink=drink;
		m_live=live;
		m_hobby=hobby;
		m_price=price;
	}
	
	public int getID(){
		return m_ID;
	}
	
	public String getName() {
		return m_name;
	}
	
	public String getEat(){
		return m_eat;
	}
	
	public String getDrink(){
		return m_drink;
	}
	
	public String getLive() {
		return m_live;
	}
	
	public String getHobby(){
		return m_hobby;
	}
	
	public int getPrice() {
		return m_price;
	}
}
