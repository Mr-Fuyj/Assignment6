package pojo;

public class User {
	private int m_ID;
	private String m_userName;
	private String m_password;
	private String m_email;
	private String m_cart;
	private int m_balance;
	private Goods m_goods;
	
	public User(int ID,String userName,String password,String email,int balance,String cart){
		m_ID=ID;
		m_userName=userName;
		m_password=password;
		m_email=email;
		m_balance=balance;
		m_cart=cart;
		m_goods=new Goods(cart);
		
	}
	
	public int getID() {
		return m_ID;
	}

	public String getUserName() {
		return m_userName;
	}

	public String getPassword() {
		return m_password;
	}

	public String getEmail() {
		return m_email;
	}

	public int getBalance() {
		return m_balance;
	}

	public String getCart(){
		return m_goods.getCart();
	}
	
	public Goods getGoods(){
		return m_goods;
	}
	
	public void addGoods(int kind,int addAmount){
		m_goods.setGood(kind, addAmount);
	}
	public void setBalance(int balance) {
		this.m_balance = balance;
		System.out.println(String.valueOf(m_balance));
	}
	
	public void setCart(String cart){
		this.m_cart=cart;
	}
	
	public void setGoods(String goods){
		m_goods=new Goods(goods);
	}
	
	//for test
	private void outToConsole(){
		System.out.println(String.valueOf(m_balance));
	}
}
