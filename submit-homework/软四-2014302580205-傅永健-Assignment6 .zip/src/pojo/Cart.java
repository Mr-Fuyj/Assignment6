package pojo;

public class Cart {
	Goods m_goods;
	PetList m_petList;
	User m_user;
	
	public Cart(Goods goods ,PetList petList,User user){
		m_goods=goods;
		m_petList=petList;
		m_user=user;
	}
	
	public Goods getGoods(){
		return m_goods;
	}
	
	public PetList getpList(){
		return m_petList;
	}
	
	public User getUser(){
		return m_user;
	}
	
	public void setGoods(Goods goods){
		m_goods=goods;
	}
	
}
