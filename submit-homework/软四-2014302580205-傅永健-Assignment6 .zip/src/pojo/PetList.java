package pojo;

import java.util.ArrayList;

public class PetList extends Entity {
	private ArrayList<Pet> m_petList;
	
	public PetList(){
		m_petList=new ArrayList<Pet>();
	}
	
	public void addPet(Pet pet){
		Pet temp=new Pet(pet.getID(), pet.getName(),pet.getEat(),pet.getDrink(),pet.getLive(),pet.getHobby(),pet.getPrice());
		m_petList.add(temp);
	}
	
	public ArrayList<Pet> getPetList(){
		return m_petList;
	}
	//For test
	public void outToConsole(){
		for(Pet p:m_petList){
			System.out.printf("%d %s %s %s %s %s  %d\n",p.getID(),p.getName(),p.getEat(),p.getDrink(),p.getLive(),p.getHobby(),p.getPrice());
		}
	}
}
