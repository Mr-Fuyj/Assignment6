create table `2014302580205_user`(
	`id` int auto_increment,
    `userName` varchar(255) ,
    `password`varchar(255),
    `email`varchar(255),
    `balance` int,
    `cart` varchar(255),
    primary key(`id`)
);
CREATE TABLE `2014302580205_pet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `eat` varchar(255) NOT NULL DEFAULT '',
  `drink` varchar(255) NOT NULL DEFAULT '',
  `live` varchar(255) NOT NULL DEFAULT '',
  `hobby` varchar(255) NOT NULL DEFAULT '',
  `price` int(11) ,
  PRIMARY KEY (`id`)
)